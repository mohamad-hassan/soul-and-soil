<?php
return array(
    'current_version'=>'3.1.7',
    'update_version'=>'3.1.8'
);
